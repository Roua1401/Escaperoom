/* ==================== Popup Helper ==================== */
function showPopup(hintText, imageSrc, divId) {
    const hint = document.getElementById('hinweis');
    hint.textContent = hintText;
    const container = document.getElementById('container');

    if (document.getElementById(divId)) return;

    const popupDiv = document.createElement('div');
    popupDiv.id = divId;
    popupDiv.className = 'picDiv';

    const img = document.createElement('img');
    img.src = imageSrc;
    img.className = 'fragen';

    popupDiv.appendChild(img);
    container.appendChild(popupDiv);

    popupDiv.onclick = function(e) {
        if (e.target === popupDiv) {
            container.removeChild(popupDiv);
            hint.textContent = "Klicke ein Objekt an!";
        }
    };
}

function showBox(hintText, coverImage, letterImage, divId) {
    const hint = document.getElementById('hinweis');
    hint.textContent = hintText;
    const container = document.getElementById('container');

    const boxDiv = document.createElement('div');
    boxDiv.id = divId;
    boxDiv.className = 'picDiv';

    const flipContainer = document.createElement('div');
    flipContainer.className = 'flip-container1';

    const pic = document.createElement('img');
    pic.src = coverImage;
    pic.onclick = function() {
        hint.textContent = "Frage: Wähle den passenden Buchstaben!";
        flipContainer.innerHTML = '';
        const letter = document.createElement('img');
        letter.src = letterImage;
        letter.classList.add('fragen');
        flipContainer.appendChild(letter);
    };

    flipContainer.appendChild(pic);
    boxDiv.appendChild(flipContainer);
    container.appendChild(boxDiv);

    boxDiv.onclick = function(e) {
        if (e.target === boxDiv) {
            container.removeChild(boxDiv);
            hint.textContent = "Klicke ein Objekt an!";
        }
    };
}

/* ==================== Letter Puzzle ==================== */
let pervPos = Array(9).fill(0);
const rightPos = [270, 270, 270, 90, 180, 0, 180, 90, 180];
let isSolved = false;

function openpic() {
    const hint = document.getElementById('hinweis');
    hint.textContent = "Frage 4: Wähle den passenden Buchstaben!";

    const container = document.getElementById('container');

    const picDiv = document.createElement('div');
    picDiv.className = 'picDiv';
    picDiv.id = 'picDiv';

    const flipContainer = document.createElement('div');
    flipContainer.className = 'flip-container';

    const front = document.createElement('div');
    front.className = 'front';
    const back = document.createElement('div');
    back.className = 'back';

    if (isSolved) {
        back.innerHTML = `
            <h2>Was ist kein Betriebssystem?</h2>
            <p> M) Linux</p>
            <p> T) Google Chrome</p>
            <p> W) Android</p>
        `;
    } else {
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                let pic = document.createElement('img');
                pic.src = `images/split/${j}${i}.jpg`;
                pic.id = `b${i}${j}`;
                pic.classList.add('picSplit');
                front.appendChild(pic);

                pic.onclick = ((index) => {
                    return function () {
                        if (finished()) return;
                        pervPos[index] = (pervPos[index] + 90) % 360;
                        pic.style.transform = `rotateZ(${pervPos[index]}deg)`;
                        if (finished()) {
                            front.innerHTML = "";
                            back.innerHTML = `
                               <h2>Was ist kein Betriebssystem?</h2>
                               <p> M) Linux </p>
                               <p> T) Google Chrome </p>
                               <p> W) Android</p>
                            `;
                            hint.textContent = "Frage 4: Wähle den passenden Buchstaben!";
                            isSolved = true;
                        }
                    };
                })(i * 3 + j);
            }
        }
    }

    flipContainer.appendChild(front);
    flipContainer.appendChild(back);
    picDiv.appendChild(flipContainer);
    container.appendChild(picDiv);

    picDiv.onclick = function(e) {
        if (e.target === picDiv) {
            container.removeChild(picDiv);
            hint.textContent = "Klicke ein Objekt an!";
        }
    };
}

function finished() {
    return pervPos.every((pos, i) => pos === rightPos[i]);
}

/* ==================== Object Popups ==================== */
function openDesk() { showPopup("Frage 1: Wähle den passenden Buchstaben aus.", "images/computerImg.png", "deskDiv"); }
function openLampe() { showPopup("Frage 9: Wähle den passenden Buchstaben aus.", "images/Frage.png", "lampeDiv"); }
function openPflanze() { showPopup("Frage 8: Wähle den passenden Buchstaben aus.", "images/pflanze.jpg", "pflanzeDiv"); }
function openSchuhkasten() { showPopup("Frage 7: Wähle den passenden Buchstaben aus.", "images/schuhsolhe.png", "schuhDiv"); }
function openUhr() { showPopup("Frage 6: Wähle den passenden Buchstaben aus.", "images/digitaleUhr.png", "uhrDiv"); }
function openBox1() { showBox("Frage 2: Wähle den passenden Buchstaben aus.", "images/cover.jpg", "images/FrageNeu.png", "boxDiv1"); }
function openBox2() { showBox("Frage 3: Wähle den passenden Buchstaben aus.", "images/cover.jpg", "images/FrageNeu2.png", "boxDiv2"); }
function openBox3() { showBox("Frage 10: Wähle den passenden Buchstaben aus.", "images/cover.jpg", "images/FrageNeu3.png", "boxDiv3"); }

/* ==================== Clock Popup ==================== */
function flipClock() {
    const container = document.getElementById('container');
    const hint = document.getElementById('hinweis');
    hint.textContent =  "Frage 5: Wähle den passenden Buchstaben aus.";

    if (document.getElementById('clockDiv')) return;

    const clockDiv = document.createElement('div');
    clockDiv.id = 'clockDiv';
    clockDiv.className = 'picDiv';

    const flipContainer = document.createElement('div');
    flipContainer.className = 'flip-container1';

    const pic = document.createElement('img');
    pic.src = "images/clock.png";
    pic.id = 'clockPic';
    pic.onclick = function() {
        flipContainer.innerHTML = '';
        const letter = document.createElement('img');
        letter.src = "images/wandUHr.png";
        letter.id = 'FrageUhr';
        flipContainer.appendChild(letter);
    };

    flipContainer.appendChild(pic);
    clockDiv.appendChild(flipContainer);
    container.appendChild(clockDiv);

    clockDiv.onclick = function(e) {
        if (e.target === clockDiv) {
            container.removeChild(clockDiv);
            hint.textContent = "Klicke ein Objekt an!";
        }
    };
}

/* ==================== Treasure & Win ==================== */
let savedGuesses = Array(10).fill("A");

function openTreasure() {
    const container = document.getElementById('container');
    const hint = document.getElementById('hinweis');
    hint.textContent = "Lass uns das Objekt näher betrachten!";
    if (document.getElementById('treasureDiv')) return;

    const treasureDiv = document.createElement('div');
    treasureDiv.id = 'treasureDiv';
    treasureDiv.className = 'picDiv';

    const flipContainer = document.createElement('div');
    flipContainer.className = 'flip-container1';

    const pic = document.createElement('img');
    pic.src = "images/treasure.png";
    pic.id = 'treasurePic';

    pic.onclick = function () {
        hint.textContent = "Das Geheimwort lautet .... (Trage die Buchstaben ein!)";
        flipContainer.innerHTML = '';

        flipContainer.innerHTML = `
        <div class="inpDiv">
            <h1>Das Geheimwort lautet:</h1>
            <div class="ersteReihe">
                ${savedGuesses.map((value,index) => `<input class="guess" id="treasure_guess${index+1}" type="text" value="${value}" readonly>`).join('')}
            </div>
            <div class="zweiteReihe">
                ${savedGuesses.map((_,index) => `<button class="guessBtns" onclick="countUp('treasure_guess${index+1}')">▴</button>`).join('')}
            </div>
            <div class="dritteReihe">
                ${savedGuesses.map((_,index) => `<button class="guessBtns" onclick="countDown('treasure_guess${index+1}')">▾</button>`).join('')}
            </div>
            <div id="button">
                <button id="check" onclick="checkTreasure()">Check Solution</button>
            </div>
        </div>`;
    };

    flipContainer.appendChild(pic);
    treasureDiv.appendChild(flipContainer);
    container.appendChild(treasureDiv);

    treasureDiv.onclick = function(e) {
        if (e.target === treasureDiv) {
            const inputs = document.querySelectorAll('.guess');
            inputs.forEach((input,index)=> savedGuesses[index]=input.value);
            container.removeChild(treasureDiv);
            hint.textContent = "Klicke ein Objekt an!";
        }
    };
}

function countUp(inputId) {
    const input = document.getElementById(inputId);
    let code = input.value.charCodeAt(0);
    input.value = (code < 90) ? String.fromCharCode(code+1) : 'A';
}

function countDown(inputId) {
    const input = document.getElementById(inputId);
    let code = input.value.charCodeAt(0);
    input.value = (code > 65) ? String.fromCharCode(code-1) : 'Z';
}

function checkTreasure() {
    const word = ["W","I","R","T","S","C","H","A","F","T"];
    let isCorrect = true;

    word.forEach((letter,index)=>{
        const input = document.getElementById(`treasure_guess${index+1}`);
        input.classList.remove('richtig','falsch');
        if(input.value === letter) input.classList.add('richtig');
        else {
            input.classList.add('falsch');
            isCorrect=false;
        }
    });

    if(isCorrect) openWinTreasure();
}

function openWinTreasure() {
    const hint = document.getElementById('hinweis');
    hint.textContent = "WOW! Du hast das Geheimwort entschlüsselt!";
    const container = document.getElementById('container');
    const treasureDiv = document.getElementById('treasureDiv');
    if(treasureDiv) container.removeChild(treasureDiv);

    const winDiv = document.createElement('div');
    winDiv.id = 'winDiv';
    winDiv.className = 'picDiv';
    winDiv.innerHTML = `<div id="kiste_offen_con" onclick="useKey()"><img src="images/kiste_offen.png" id="kiste_offen"></div>`;
    container.appendChild(winDiv);
}

function useKey() {
    const hint = document.getElementById('hinweis');
    hint.textContent = "Super! Wir haben den Schlüssel! Lass uns die Tür öffnen!";
    const winDiv = document.getElementById('winDiv');
    winDiv.innerHTML = `<div id="keyCon" onclick="opendoor()"><img src="images/key.webp" id="key"></div>`;
}

function opendoor() {
    const hint = document.getElementById('hinweis');
    hint.textContent = "GEWONNEN!";
    const winDiv = document.getElementById("winDiv");
    winDiv.innerHTML = '';

    const tuerCon = document.getElementById("tür");
    tuerCon.innerHTML = `<img src="images/openedDoor.png" alt="opendoor" id="opendoor">`;

    winDiv.innerHTML = `<h1 class="winText">WIN!!!</h1>
    <span class="winText">Herzlichen Glückwunsch! <br>Du hast gewonnen! 🎉</span>`;
}
